# AI Konsentrasi & Engagement Mahasiswa (SDG 4)

Streamlit app untuk memprediksi:
- Engagement (tabular) -> Low/Medium/High + skor 0-100
- Konsentrasi (image) -> Low/Medium/High + skor 0-100
- Rekomendasi metode belajar adaptif
